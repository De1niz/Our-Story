package com.ourstory;

import com.jme3.math.ColorRGBA;
import com.jme3.math.Vector3f;

/** The 12 portals in the memory hub. */
public class HubScene {
    private final WorldBuilder world;
    private final Vector3f[] portalPositions = new Vector3f[12];

    public HubScene(WorldBuilder world) { this.world=world; }
    public void build() {
        world.ground();
        world.path(0,29);
        for (int i=0;i<12;i++) {
            int row=i/2;
            float x=i%2==0?-6.8f:6.8f;
            float z= -24+row*9f;
            portalPositions[i]=new Vector3f(x,0,z);
            var pillar=world.material(i==0 ? new ColorRGBA(.73f,.50f,.53f,1) : new ColorRGBA(.46f,.54f,.63f,1));
            world.block("Month "+(i+1)+" left pillar",x-1.55f,1.7f,z,.28f,1.7f,.45f,pillar,true);
            world.block("Month "+(i+1)+" right pillar",x+1.55f,1.7f,z,.28f,1.7f,.45f,pillar,true);
            world.block("Month "+(i+1)+" arch",x,3.55f,z,1.83f,.26f,.45f,pillar,true);
            world.block("Month "+(i+1)+" portal",x,1.7f,z,.9f,1.45f,.12f,
                    world.material(i==0?new ColorRGBA(.52f,.68f,.82f,1):new ColorRGBA(.33f,.40f,.48f,1)),false);
            world.block("Portal approach",x/2f,.022f,z,Math.abs(x)/2f+.8f,.015f,1.2f,world.texture("stone.png"),false);
            world.tree(-13,z); world.tree(13,z);
        }
    }
    public int nearby(Vector3f feet) {
        for (int i=0;i<portalPositions.length;i++) {
            if (portalPositions[i]!=null && feet.distance(portalPositions[i])<3.3f) return i;
        }
        return -1;
    }
}
