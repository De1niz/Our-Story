package com.ourstory;

import com.jme3.math.ColorRGBA;
import com.jme3.math.Vector3f;

/** Chapter 1 geometry and memory trigger positions. Edit story text in ChapterOneContent.java. */
public class ChapterOneScene {
    private final WorldBuilder world;
    private final Vector3f[] markers = {
            new Vector3f(2.9f,0,12f),
            new Vector3f(2.9f,0,-2f),
            new Vector3f(2.9f,0,-17f)
    };
    public ChapterOneScene(WorldBuilder world) { this.world=world; }
    public void build() {
        world.ground();
        world.path(0,29);
        var brick=world.texture("stone.png");
        var wood=world.texture("wood.png");
        var pale=world.material(new ColorRGBA(.71f,.73f,.72f,1));
        var flower=world.material(new ColorRGBA(.77f,.37f,.44f,1));
        // First meeting: paved plaza and a physical stone fountain.
        world.block("Meeting plaza",0,.015f,12f,5.5f,.012f,4.7f,brick,false);
        world.block("Fountain stone basin",-3f,.48f,12f,1.1f,.48f,1.1f,pale,true);
        world.sphere("Fountain water",-3f,1.04f,12f,.75f,world.material(new ColorRGBA(.21f,.43f,.63f,1)));
        world.tree(6f,16f); world.tree(-7f,8f);
        // First date: a café counter with solid walls, tables, seats and canopy.
        world.block("Cafe terrace",0,.015f,-2f,5.5f,.012f,5f,brick,false);
        world.block("Cafe back wall",0,2f,-6.2f,4f,2f,.4f,pale,true);
        world.block("Cafe roof",0,4.05f,-6.2f,4.6f,.22f,1.25f,wood,true);
        world.block("Cafe counter",0,.8f,-4.8f,2.5f,.8f,.55f,wood,true);
        for (int side : new int[]{-1,1}) {
            float x=side*3f;
            world.block("Solid cafe table",x,.78f,-1.8f,.8f,.08f,.8f,wood,true);
            world.block("Cafe table support",x,.4f,-1.8f,.11f,.4f,.11f,wood,true);
            world.bench(x,-.1f);
        }
        // Memory garden: trees, solid benches, planted flower beds.
        world.block("Garden walk",0,.014f,-17f,5.6f,.012f,4.2f,brick,false);
        world.bench(-3.4f,-17f);
        for (int i=-4;i<=4;i+=2) {
            world.sphere("Flower",i,.3f,-20.4f,.25f,flower);
            world.sphere("Flower",i,.3f,-13.6f,.25f,flower);
        }
        world.tree(7f,-18f); world.tree(-7f,-19f);
        for (int i=0;i<markers.length;i++) {
            Vector3f pos=markers[i];
            world.block("Memory marker "+(i+1),pos.x,.65f,pos.z,.28f,.65f,.28f,
                    world.material(new ColorRGBA(.79f,.54f,.58f,1)),false);
        }
        for (int i=-30;i<=30;i+=12) {
            world.tree(-15f,i); world.tree(15f,i);
        }
    }
    public int nearby(Vector3f feet) {
        for (int i=0;i<markers.length;i++) if (feet.distance(markers[i])<2.7f) return i;
        return -1;
    }
}
