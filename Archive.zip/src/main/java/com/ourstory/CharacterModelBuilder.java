package com.ourstory;

import com.jme3.asset.AssetManager;
import com.jme3.material.Material;
import com.jme3.math.ColorRGBA;
import com.jme3.renderer.queue.RenderQueue;
import com.jme3.scene.Geometry;
import com.jme3.scene.Node;
import com.jme3.scene.shape.Box;
import com.jme3.scene.shape.Sphere;

/** Procedural prototype. Replace with licensed, rigged human meshes for realism. */
public final class CharacterModelBuilder {
    private final AssetManager assets;
    public CharacterModelBuilder(AssetManager assets) { this.assets = assets; }

    public Node build(CharacterData data) {
        Node root = new Node("Player " + data.playerNumber + " Preview");
        float width = new float[]{.82f, 1f, 1.23f}[data.choices[3]];
        float height = new float[]{.91f, 1f, 1.09f}[data.choices[4]];
        ColorRGBA skin = data.playerNumber == 1 ? new ColorRGBA(.74f,.54f,.40f,1) : new ColorRGBA(.67f,.45f,.34f,1);
        ColorRGBA cloth = data.playerNumber == 1 ? new ColorRGBA(.25f,.40f,.55f,1) : new ColorRGBA(.65f,.34f,.44f,1);
        ColorRGBA hair = data.playerNumber == 1 ? new ColorRGBA(.16f,.11f,.09f,1) : new ColorRGBA(.26f,.17f,.11f,1);
        ColorRGBA pants = new ColorRGBA(.21f,.25f,.31f,1);
        piece(root,"Leg",-.22f,.65f,0,.16f,.43f,.19f,pants);
        piece(root,"Leg", .22f,.65f,0,.16f,.43f,.19f,pants);
        piece(root,"Boot",-.22f,.18f,-.04f,.17f,.17f,.25f,ColorRGBA.DarkGray);
        piece(root,"Boot", .22f,.18f,-.04f,.17f,.17f,.25f,ColorRGBA.DarkGray);
        piece(root,"Body",0,1.47f,0,.43f*width,.48f,.26f*width,cloth);
        piece(root,"Body",-.56f*width,1.43f,0,.14f,.41f,.15f,cloth);
        piece(root,"Body", .56f*width,1.43f,0,.14f,.41f,.15f,cloth);
        piece(root,"Face",0,2.16f,0,.32f*new float[]{.85f,1f,1.18f}[data.choices[0]],.35f,.31f,skin,true);
        // Face looks forward, toward -Z (the preview camera sees a slight front angle).
        piece(root,"Face",-.12f,2.18f,-.305f,.038f,.04f,.03f,ColorRGBA.White,true);
        piece(root,"Face", .12f,2.18f,-.305f,.038f,.04f,.03f,ColorRGBA.White,true);
        piece(root,"Face",-.12f,2.18f,-.34f,.016f,.022f,.01f,ColorRGBA.DarkGray,true);
        piece(root,"Face", .12f,2.18f,-.34f,.016f,.022f,.01f,ColorRGBA.DarkGray,true);
        int hairstyle=data.choices[1];
        if (hairstyle==0) {
            piece(root,"Hair",0,2.47f,0,.31f,.10f,.32f,hair);
        } else if (hairstyle==1) {
            piece(root,"Hair",0,2.49f,0,.33f,.14f,.32f,hair);
            piece(root,"Hair",-.28f,2.37f,0,.06f,.14f,.29f,hair);
        } else if (hairstyle==2) {
            piece(root,"Hair",0,2.47f,0,.34f,.12f,.33f,hair);
            piece(root,"Hair",-.32f,2.18f,0,.10f,.32f,.28f,hair);
            piece(root,"Hair", .32f,2.18f,0,.10f,.32f,.28f,hair);
        } else {
            piece(root,"Hair",0,2.47f,0,.32f,.10f,.31f,hair);
            piece(root,"Hair",0,2.47f,.35f,.16f,.17f,.16f,hair,true);
        }
        if(data.choices[2] != 0) {
            float thickness = data.choices[2] == 1 ? .035f : .075f;
            piece(root,"Beard",0,1.91f,-.24f,.22f,thickness,.12f,hair);
            if (data.choices[2] == 2) {
                piece(root,"Beard",-.24f,2.02f,-.19f,.07f,.18f,.12f,hair);
                piece(root,"Beard", .24f,2.02f,-.19f,.07f,.18f,.12f,hair);
            }
        }
        root.setLocalScale(1f,height,1f);
        return root;
    }

    private void piece(Node root,String part,float x,float y,float z,float a,float b,float c,ColorRGBA color) {
        piece(root,part,x,y,z,a,b,c,color,false);
    }
    private void piece(Node root,String part,float x,float y,float z,float a,float b,float c,ColorRGBA color,boolean round) {
        Geometry g = new Geometry(part,round ? new Sphere(16,20,1f) : new Box(1,1,1));
        g.setLocalScale(a,b,c);
        g.setLocalTranslation(x,y,z);
        Material m=new Material(assets,"Common/MatDefs/Light/Lighting.j3md");
        m.setBoolean("UseMaterialColors",true);
        m.setColor("Diffuse",color);
        m.setColor("Ambient",color.mult(.8f));
        m.setColor("Specular",ColorRGBA.White.mult(.12f));
        m.setFloat("Shininess",22f);
        g.setMaterial(m);
        g.setUserData("part",part);
        g.setShadowMode(RenderQueue.ShadowMode.CastAndReceive);
        root.attachChild(g);
    }
}
