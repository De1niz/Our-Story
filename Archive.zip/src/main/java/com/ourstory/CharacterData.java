package com.ourstory;

/** Editable, independent appearance presets for one player. */
public final class CharacterData {
    public static final String[] CATEGORIES = {"Face", "Hair", "Beard", "Body", "Height"};
    public static final String[][] OPTIONS = {
            {"Narrow", "Balanced", "Wide"},
            {"Short", "Side Part", "Long", "Bun"},
            {"None", "Stubble", "Full"},
            {"Slim", "Regular", "Broad"},
            {"Short", "Average", "Tall"}
    };
    public final int playerNumber;
    public final int[] choices = {1, 1, 0, 1, 1};
    public int category;
    public boolean ready;

    public CharacterData(int playerNumber) { this.playerNumber = playerNumber; }
    public String categoryName() { return CATEGORIES[category]; }
    public String choiceName() { return OPTIONS[category][choices[category]]; }
    public void changeCategory(int increment) {
        category = Math.floorMod(category + increment, CATEGORIES.length);
    }
    public void changeOption(int increment) {
        choices[category] = Math.floorMod(choices[category] + increment, OPTIONS[category].length);
        ready = false;
    }
}
