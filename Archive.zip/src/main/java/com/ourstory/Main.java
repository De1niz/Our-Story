package com.ourstory;

import com.jme3.app.SimpleApplication;
import com.jme3.bullet.BulletAppState;
import com.jme3.font.BitmapText;
import com.jme3.input.KeyInput;
import com.jme3.input.MouseInput;
import com.jme3.input.controls.MouseButtonTrigger;
import com.jme3.input.controls.ActionListener;
import com.jme3.input.controls.KeyTrigger;
import com.jme3.light.AmbientLight;
import com.jme3.light.DirectionalLight;
import com.jme3.material.Material;
import com.jme3.math.ColorRGBA;
import com.jme3.math.Vector3f;
import com.jme3.renderer.queue.RenderQueue;
import com.jme3.scene.Geometry;
import com.jme3.scene.Node;
import com.jme3.scene.shape.Box;
import com.jme3.shadow.DirectionalLightShadowRenderer;
import com.jme3.system.AppSettings;

/** Our Story v2: a single-player foundation for later co-op. All in-game text is English. */
public class Main extends SimpleApplication implements ActionListener {
    private enum Screen { SELECT, HUB, CHAPTER_ONE, MONTH }
    private Screen screen=Screen.SELECT;
    private final Node environment=new Node("Environment");
    private final Node avatar=new Node("Selected Character");
    private final Node creatorStage=new Node("Character Creator Preview");
    private CharacterCreatorScreen creator;
    private BulletAppState bullet;
    private PlayerController player;
    private WorldBuilder builder;
    private HubScene hub;
    private ChapterOneScene chapter;
    private BitmapText title,subtitle,story,progress,instructions;
    private int month=2;
    private final boolean[] visited=new boolean[3];
    private DirectionalLight sun;

    public static void main(String[] args) {
        Main app=new Main();
        AppSettings settings=new AppSettings(true);
        settings.setTitle("Our Story — Character Creator v1");
        settings.setResolution(1280,720);
        settings.setVSync(true);
        app.setSettings(settings);
        app.setShowSettings(false);
        app.start();
    }

    @Override public void simpleInitApp() {
        setDisplayFps(false); setDisplayStatView(false);
        flyCam.setEnabled(false);
        rootNode.attachChild(environment);
        rootNode.attachChild(avatar);
        rootNode.attachChild(creatorStage);
        viewPort.setBackgroundColor(new ColorRGBA(.58f,.72f,.83f,1));
        AmbientLight ambient=new AmbientLight();
        ambient.setColor(ColorRGBA.White.mult(.55f));
        rootNode.addLight(ambient);
        sun=new DirectionalLight();
        sun.setDirection(new Vector3f(-.45f,-1f,-.35f).normalizeLocal());
        sun.setColor(new ColorRGBA(1f,.92f,.79f,1).mult(1.3f));
        rootNode.addLight(sun);
        DirectionalLightShadowRenderer shadows=new DirectionalLightShadowRenderer(assetManager,1024,3);
        shadows.setLight(sun);
        viewPort.addProcessor(shadows);
        bullet=new BulletAppState();
        stateManager.attach(bullet);
        builder=new WorldBuilder(assetManager,bullet.getPhysicsSpace(),environment);
        hub=new HubScene(builder);
        chapter=new ChapterOneScene(builder);
        creator=new CharacterCreatorScreen(assetManager,creatorStage,cam);
        createAvatar();
        player=new PlayerController(bullet.getPhysicsSpace(),avatar,cam,inputManager);
        inputManager.addMapping("Interact",new KeyTrigger(KeyInput.KEY_E),new KeyTrigger(KeyInput.KEY_RETURN));
        inputManager.addMapping("Back",new KeyTrigger(KeyInput.KEY_BACK));
        inputManager.addMapping("Character1",new KeyTrigger(KeyInput.KEY_1));
        inputManager.addMapping("Character2",new KeyTrigger(KeyInput.KEY_2));
        inputManager.addListener(this,"Interact","Back","Character1","Character2");
        // Player 1: A/D categories, W/S options, R ready.
        // Player 2: Left/Right categories, Up/Down options, Return ready.
        inputManager.addMapping("P1CatPrev",new KeyTrigger(KeyInput.KEY_A));
        inputManager.addMapping("P1CatNext",new KeyTrigger(KeyInput.KEY_D));
        inputManager.addMapping("P1OptPrev",new KeyTrigger(KeyInput.KEY_S));
        inputManager.addMapping("P1OptNext",new KeyTrigger(KeyInput.KEY_W));
        inputManager.addMapping("P1Ready",new KeyTrigger(KeyInput.KEY_R));
        inputManager.addMapping("P2CatPrev",new KeyTrigger(KeyInput.KEY_LEFT));
        inputManager.addMapping("P2CatNext",new KeyTrigger(KeyInput.KEY_RIGHT));
        inputManager.addMapping("P2OptPrev",new KeyTrigger(KeyInput.KEY_DOWN));
        inputManager.addMapping("P2OptNext",new KeyTrigger(KeyInput.KEY_UP));
        inputManager.addMapping("P2Ready",new KeyTrigger(KeyInput.KEY_RETURN));
        inputManager.addMapping("CreatorClick",new MouseButtonTrigger(MouseInput.BUTTON_LEFT));
        inputManager.addMapping("CreatorZoomOut",new KeyTrigger(KeyInput.KEY_ESCAPE));
        inputManager.addMapping("CreatorStart",new KeyTrigger(KeyInput.KEY_F));
        inputManager.addListener(this,"P1CatPrev","P1CatNext","P1OptPrev","P1OptNext","P1Ready",
                "P2CatPrev","P2CatNext","P2OptPrev","P2OptNext","P2Ready",
                "CreatorClick","CreatorZoomOut","CreatorStart");
        createReadableHudPanels();
        title=ui(26,cam.getHeight()-28,29);
        subtitle=ui(26,cam.getHeight()-69,18);
        progress=ui(26,120,18);
        story=ui(26,89,16);
        instructions=ui(26,47,16);
        showSelection();
    }

    // Opaque, light UI panels keep black text readable on every background.
    private void createReadableHudPanels() {
        addHudPanel("Top readable panel",cam.getWidth()/2f,cam.getHeight()-57f,
                cam.getWidth()/2f,57f);
        addHudPanel("Bottom readable panel",cam.getWidth()/2f,68f,
                cam.getWidth()/2f,68f);
    }

    private void addHudPanel(String name,float x,float y,float hx,float hy) {
        Geometry panel=new Geometry(name,new Box(hx,hy,.001f));
        Material mat=new Material(assetManager,"Common/MatDefs/Misc/Unshaded.j3md");
        mat.setColor("Color",new ColorRGBA(.96f,.95f,.92f,1));
        panel.setMaterial(mat);
        panel.setLocalTranslation(x,y,-1f);
        guiNode.attachChild(panel);
    }

    private BitmapText ui(int x,int y,int fontSize) {
        BitmapText text=new BitmapText(guiFont);
        text.setSize(fontSize);
        text.setColor(ColorRGBA.Black);
        text.setLocalTranslation(x,y,0);
        guiNode.attachChild(text);
        return text;
    }

    private void createAvatar() {
        avatar.detachAllChildren();
        CharacterData selection = creator == null ? new CharacterData(1) : creator.get(0);
        avatar.attachChild(new CharacterModelBuilder(assetManager).build(selection));
    }

    private void loadWorld() {
        builder.clear();
        player.setEnabled(false);
        progress.setText(""); story.setText("");
    }

    private void showSelection() {
        screen=Screen.SELECT;
        loadWorld();
        avatar.setCullHint(com.jme3.scene.Spatial.CullHint.Always);
        builder.ground();
        builder.block("Showroom platform 1",-2.2f,.08f,0,1.45f,.08f,1.4f,builder.texture("stone.png"),false);
        builder.block("Showroom platform 2",2.2f,.08f,0,1.45f,.08f,1.4f,builder.texture("stone.png"),false);
        creator.show();
        title.setText("OUR STORY - CHARACTER CREATOR");
        refreshCreatorText();
    }

    private void refreshCreatorText() {
        CharacterData p1=creator.get(0),p2=creator.get(1);
        subtitle.setText("PLAYER 1: "+p1.categoryName()+" / "+p1.choiceName()+" ["+(p1.ready?"READY":"EDITING")+"]");
        progress.setText("PLAYER 2: "+p2.categoryName()+" / "+p2.choiceName()+" ["+(p2.ready?"READY":"EDITING")+"]");
        story.setText("P1: A/D category, W/S choice, R ready | P2: arrows category/choice, ENTER ready");
        instructions.setText("Click a body part to zoom | ESC reset view | F start when BOTH READY");
    }

    private void showHub() {
        screen=Screen.HUB;
        creator.hide();
        avatar.setCullHint(com.jme3.scene.Spatial.CullHint.Inherit);
        createAvatar();
        loadWorld();
        hub.build();
        player.teleport(new Vector3f(0,.12f,32));
        player.setEnabled(true);
        title.setText("WORLD OF MEMORIES");
        subtitle.setText("Explore the 12 portals. Walk near a portal and press E.");
        instructions.setText("WASD move | Mouse look | SPACE jump | E enter | BACKSPACE back");
    }

    private void showChapter() {
        screen=Screen.CHAPTER_ONE;
        loadWorld();
        chapter.build();
        player.teleport(new Vector3f(0,.12f,27));
        player.setEnabled(true);
        title.setText("CHAPTER 1 - THE BEGINNING OF US");
        subtitle.setText(ChapterOneContent.CHAPTER_INTRO);
        story.setText("Explore all three memory markers.");
        updateProgress();
        instructions.setText("WASD move | Mouse look | SPACE jump | E memory | BACKSPACE hub");
    }

    private void showMonth(int index) {
        screen=Screen.MONTH; month=index;
        loadWorld();
        builder.ground(); builder.path(0,28);
        for(int z=-25;z<=25;z+=10){ builder.tree(-9,z);builder.tree(9,z); }
        builder.block("Stone memory monument",0,1,-12,2,1,2,builder.texture("stone.png"),true);
        player.teleport(new Vector3f(0,.12f,23));
        player.setEnabled(true);
        title.setText("MONTH "+index+" - MEMORY WORLD");
        subtitle.setText("This memory world is ready for your future chapter.");
        story.setText("Your story will be added here later.");
        instructions.setText("WASD move | Mouse look | SPACE jump | BACKSPACE hub");
    }

    private void updateProgress() {
        int count=0;
        for(boolean value:visited) if(value) count++;
        progress.setText("MEMORIES DISCOVERED: "+count+" / 3");
        if (count==3) story.setText(ChapterOneContent.CHAPTER_END);
    }

    @Override public void simpleUpdate(float tpf) {
        if(screen==Screen.SELECT) { creator.update(tpf); return; }
        player.update(tpf);
        if(screen==Screen.HUB) {
            int near=hub.nearby(player.getFeet());
            subtitle.setText(near<0 ? "Explore the 12 portals. Walk near a portal and press E." :
                    "MONTH "+(near+1)+" - Press E to enter the portal.");
        } else if(screen==Screen.CHAPTER_ONE) {
            int near=chapter.nearby(player.getFeet());
            instructions.setText(near<0 ? "WASD move | Mouse look | SPACE jump | E memory | BACKSPACE hub" :
                    "Press E: "+ChapterOneContent.TITLES[near]+" | BACKSPACE hub");
        }
    }

    @Override public void onAction(String name,boolean pressed,float tpf) {
        if(!pressed) return;
        if(screen==Screen.SELECT) {
            switch(name) {
                case "P1CatPrev": creator.changeCategory(0,-1); break;
                case "P1CatNext": creator.changeCategory(0,1); break;
                case "P1OptPrev": creator.changeOption(0,-1); break;
                case "P1OptNext": creator.changeOption(0,1); break;
                case "P1Ready": creator.toggleReady(0); break;
                case "P2CatPrev": creator.changeCategory(1,-1); break;
                case "P2CatNext": creator.changeCategory(1,1); break;
                case "P2OptPrev": creator.changeOption(1,-1); break;
                case "P2OptNext": creator.changeOption(1,1); break;
                case "P2Ready": creator.toggleReady(1); break;
                case "CreatorZoomOut": creator.resetCamera(); break;
                case "CreatorClick": creator.click(inputManager); break;
                case "CreatorStart": if(creator.bothReady()) showHub(); break;
                default: break;
            }
            if(screen==Screen.SELECT) refreshCreatorText();
            return;
        }
        if(name.equals("Back")) {
            if(screen==Screen.HUB) showSelection(); else showHub();
        } else if(name.equals("Interact")&&screen==Screen.HUB) {
            int index=hub.nearby(player.getFeet());
            if(index==0) showChapter(); else if(index>0) showMonth(index+1);
        } else if(name.equals("Interact")&&screen==Screen.CHAPTER_ONE) {
            int i=chapter.nearby(player.getFeet());
            if(i>=0) {
                visited[i]=true;
                subtitle.setText(ChapterOneContent.TITLES[i]+" | "+ChapterOneContent.PLACES[i]);
                story.setText(ChapterOneContent.MEMORIES[i]);
                updateProgress();
            }
        }
    }
}
