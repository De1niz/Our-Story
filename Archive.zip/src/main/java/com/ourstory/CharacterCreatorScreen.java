package com.ourstory;

import com.jme3.asset.AssetManager;
import com.jme3.collision.CollisionResult;
import com.jme3.collision.CollisionResults;
import com.jme3.input.InputManager;
import com.jme3.math.FastMath;
import com.jme3.math.Ray;
import com.jme3.math.Vector2f;
import com.jme3.math.Vector3f;
import com.jme3.renderer.Camera;
import com.jme3.scene.Node;

/** Both player profiles are shown and edited independently on one computer. */
public final class CharacterCreatorScreen {
    private final CharacterData[] players = {new CharacterData(1),new CharacterData(2)};
    private final CharacterModelBuilder models;
    private final Node stage;
    private final Node[] previews = new Node[2];
    private final Camera camera;
    private int focusPlayer = -1;
    private int focusCategory;
    private float focusTime;
    private final Vector3f homePosition = new Vector3f(0,3.0f,11f);
    private final Vector3f homeTarget = new Vector3f(0,1.4f,0);
    private final Vector3f lookTarget = homeTarget.clone();

    public CharacterCreatorScreen(AssetManager assets,Node stage,Camera camera) {
        this.models=new CharacterModelBuilder(assets);
        this.stage=stage;
        this.camera=camera;
    }
    public CharacterData get(int player) { return players[player]; }
    public boolean bothReady() { return players[0].ready && players[1].ready; }

    public void show() {
        stage.detachAllChildren();
        rebuild(0);
        rebuild(1);
        focusPlayer = -1;
        focusTime = 0;
        camera.setLocation(homePosition.clone());
        lookTarget.set(homeTarget);
        camera.lookAt(lookTarget,Vector3f.UNIT_Y);
    }

    public void hide() { stage.detachAllChildren(); }

    public void changeCategory(int player,int increment) {
        players[player].changeCategory(increment);
        focus(player,players[player].category);
    }
    public void changeOption(int player,int increment) {
        players[player].changeOption(increment);
        rebuild(player);
        focus(player,players[player].category);
    }
    public void toggleReady(int player) {
        players[player].ready = !players[player].ready;
        focusPlayer=-1;
        focusTime=0;
    }
    public void resetCamera() { focusTime=0; focusPlayer=-1; }

    private void rebuild(int index) {
        if(previews[index] != null) stage.detachChild(previews[index]);
        Node preview=models.build(players[index]);
        preview.setLocalTranslation(index==0 ? -2.2f : 2.2f,.15f,0);
        preview.rotate(0,index==0 ? -.18f : .18f,0);
        previews[index]=preview;
        stage.attachChild(preview);
    }
    private void focus(int player,int category) {
        focusPlayer=player;
        focusCategory=category;
        focusTime=3.2f;
    }
    private int categoryForPart(String part) {
        if("Face".equals(part)) return 0;
        if("Hair".equals(part)) return 1;
        if("Beard".equals(part)) return 2;
        if("Body".equals(part)) return 3;
        if("Leg".equals(part)||"Boot".equals(part)) return 4;
        return -1;
    }
    public void click(InputManager input) {
        Vector2f cursor=input.getCursorPosition();
        Vector3f origin=camera.getWorldCoordinates(cursor,0f);
        Vector3f end=camera.getWorldCoordinates(cursor,1f);
        CollisionResults hits=new CollisionResults();
        stage.collideWith(new Ray(origin,end.subtract(origin).normalizeLocal()),hits);
        if(hits.size()==0) { resetCamera(); return; }
        CollisionResult hit=hits.getClosestCollision();
        String part=hit.getGeometry().getUserData("part");
        int category=categoryForPart(part);
        if(category<0) return;
        Node n=hit.getGeometry().getParent();
        for(int p=0;p<2;p++) {
            if(n==previews[p]) {
                players[p].category=category;
                focus(p,category);
                break;
            }
        }
    }
    public void update(float tpf) {
        boolean zooming=focusPlayer>=0 && focusTime>0f;
        if(zooming) focusTime-=tpf;
        float x=zooming ? (focusPlayer==0 ? -2.2f:2.2f) : 0f;
        float y=zooming ? (focusCategory<=2 ? 2.15f : focusCategory==3 ? 1.45f : 1f) : 1.4f;
        Vector3f target=new Vector3f(x,y,0);
        Vector3f cameraDestination=zooming ? new Vector3f(x+1.0f,y+.35f,3.7f) : homePosition;
        float alpha=FastMath.clamp(tpf*5f,0f,1f);
        camera.setLocation(camera.getLocation().interpolateLocal(cameraDestination,alpha));
        lookTarget.interpolateLocal(target,alpha);
        camera.lookAt(lookTarget,Vector3f.UNIT_Y);
        if(!zooming) focusPlayer=-1;
    }
}
